# Maze Run


## Short description

The only thing you've ever known is the maze. On all sides, unending, unyielding. Can today be the day you escape? Or will you fall victim to the little time that was given to you?

## Launch instructions

Launch ```main.py``` from terminal.


## Controls

WASD or arrow keys to move and mouse for menu selection.


## Assets

The artwork for the game was made by Utku.

The music was created by Titas Geryba.

## Known bugs

When changing from the high scores screen to the menu, the menu sometimes becomes non-responsive. Relaunching the file is the only solution I've found.
